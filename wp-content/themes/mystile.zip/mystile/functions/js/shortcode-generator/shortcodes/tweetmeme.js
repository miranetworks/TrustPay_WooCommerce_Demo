wooShortcodeMeta={
	attributes:[
		{
			label:"Style",
			id:"style",
			help:"Values: &lt;empty&gt; or compact.", 
			controlType:"select-control", 
			selectValues:['', 'compact'],
			defaultValue: '', 
			defaultText: 'none (Default)'
		},
		{
			label:"Link",
			id:"link",
			help:"Optional. Specify URL directly."
		},
		{
			label:"Source",
			id:"source",
			help:"Optional username."
		}
		],
		defaultContent:"",
		shortcode:"tweetmeme"
};