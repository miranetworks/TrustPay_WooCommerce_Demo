=== WooCommerce TrustPay Gateway ===

A payment gateway for TrustPay. A TrustPay User account (http://my.trustpay.biz), vendor key are required for this gateway to function.

== Important Note ==

An SSL certificate is recommended for additional safety and security for your customers.