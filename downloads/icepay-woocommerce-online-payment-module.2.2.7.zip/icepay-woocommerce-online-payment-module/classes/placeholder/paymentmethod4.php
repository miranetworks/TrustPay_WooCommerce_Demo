<?php

class ICEPAY_PaymentMethod_4 extends ICEPAY_Paymentmethod_Core {

    protected $pmCode = 4;

}
