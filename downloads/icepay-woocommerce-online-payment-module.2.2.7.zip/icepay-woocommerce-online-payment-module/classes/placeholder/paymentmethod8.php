<?php

class ICEPAY_PaymentMethod_8 extends ICEPAY_Paymentmethod_Core {

    protected $pmCode = 8;

}
