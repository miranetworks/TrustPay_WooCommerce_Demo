<?php

class ICEPAY_PaymentMethod_5 extends ICEPAY_Paymentmethod_Core {

    protected $pmCode = 5;

}
