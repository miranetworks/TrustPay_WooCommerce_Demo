<?php

class ICEPAY_PaymentMethod_10 extends ICEPAY_Paymentmethod_Core {

    protected $pmCode = 10;

}
