<?php

class ICEPAY_PaymentMethod_14 extends ICEPAY_Paymentmethod_Core {

    protected $pmCode = 14;

}
