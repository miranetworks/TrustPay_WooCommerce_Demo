<?php

class ICEPAY_PaymentMethod_1 extends ICEPAY_Paymentmethod_Core {

    protected $pmCode = 1;

}
