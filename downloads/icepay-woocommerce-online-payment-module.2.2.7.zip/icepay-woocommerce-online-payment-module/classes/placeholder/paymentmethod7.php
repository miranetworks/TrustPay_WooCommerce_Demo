<?php

class ICEPAY_PaymentMethod_7 extends ICEPAY_Paymentmethod_Core {

    protected $pmCode = 7;

}
