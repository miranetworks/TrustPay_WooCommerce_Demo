<?php

class ICEPAY_PaymentMethod_3 extends ICEPAY_Paymentmethod_Core {

    protected $pmCode = 3;

}
