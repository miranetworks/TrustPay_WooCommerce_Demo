<?php

class ICEPAY_PaymentMethod_13 extends ICEPAY_Paymentmethod_Core {

    protected $pmCode = 13;

}
