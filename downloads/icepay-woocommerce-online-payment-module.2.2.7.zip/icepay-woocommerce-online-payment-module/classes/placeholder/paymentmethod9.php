<?php

class ICEPAY_PaymentMethod_9 extends ICEPAY_Paymentmethod_Core {

    protected $pmCode = 9;

}
