<?php

class ICEPAY_PaymentMethod_12 extends ICEPAY_Paymentmethod_Core {

    protected $pmCode = 12;

}
